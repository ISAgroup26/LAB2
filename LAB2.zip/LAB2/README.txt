Forlders:
- 1 = basic pipeline multiplier
- 1.1 = fine grain pipeline
- 1.2 = second stage with MBE
- 2 = input register and different simulation