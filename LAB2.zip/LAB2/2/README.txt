
How to read files

All the files present in the syn folder were generated following different simulations. 
Files are distinguished with _[name]:

type of simulation
- file without any _[name]: simulation slack = 0, no set_implementation
- file with _0: simulation @t=0, no set_implementation

type of component
- file without CSA o PPARCH: default choice
- file with _CSA: CSA is used
- file with _PP: PPARCH is used

Each file is a combination of these two choices.
