
How to read files

All the files present in the syn folder were generated following different simulations. 
Files are distinguished with _[name]:

- file without any _[name]: simulation @t=0, optimize_registers+compile
- file with _1: simulation with slack 0 met, optimize_registers+compile
- file with _0: simulation @t=0, compile_ultra
- file with _ultra: simulation with slack met, compile_ultra
